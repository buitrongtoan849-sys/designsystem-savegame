const body = document.body;
    const themeBtn = document.getElementById("themeBtn");

    themeBtn.addEventListener("click", () => {
      body.classList.toggle("dark");
      body.classList.toggle("light");

      const isLight = body.classList.contains("light");

      themeBtn.textContent = isLight
        ? "Đổi sang Dark Mode"
        : "Đổi sang Light Mode";
    });
